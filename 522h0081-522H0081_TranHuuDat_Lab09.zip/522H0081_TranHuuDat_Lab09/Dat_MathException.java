public class Dat_MathException extends Exception{
    public Dat_MathException() {
        super();
    }
    public Dat_MathException(NumberOutOfRangeException s) {
        System.out.println("Nhap qua du lieu");
        }  
}
