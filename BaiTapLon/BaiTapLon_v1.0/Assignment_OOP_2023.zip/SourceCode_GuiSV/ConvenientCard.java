public class ConvenientCard implements Payment{
	// code here
	
    private String type;
	
	public String getType() {
		return this.type;
	}
}
